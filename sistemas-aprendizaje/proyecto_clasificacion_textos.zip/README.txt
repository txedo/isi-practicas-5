La estructura de directorios que se incluye en el proyecto es la siguiente: 

	- aplicaci�n: contiene el ejecutable de la aplicacion desarrollada por los autores del proyecto. Es una aplicaci�n basada en Java, por lo que contiene un archivo JAR.
	- articulo: contiene el articulo describiendo y detallando el proyecto.
	- codigoFuente: contiene el c�digo fuente de la aplicaci�n desarrollada.
	- misc: contiene diferentes recursos que se han utilizado y/o generado en este proyecto. Estos recursos son:
	
		* Metadatos originales, pre-procesados y extendidos.
		* Proyectos desarrollados en RapidMiner y WVTool
		* Documentos de texto utilizados.
		* Resultados obtenidos al ejecutar los proyectos.
		* Lista de stopwords en espa�ol