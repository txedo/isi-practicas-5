FAQ Manager: un gestor de FAQ hecho en Flash
--------------------------------------------

URL:
	http://chico.inf-cr.uclm.es/mhrv/2010/H10_12/faq-manager.html
	
Autores:
	Juan Andrada Romero (juan.andrada@uclm.es)
	Jose Domingo Lopez Lopez (josed.lopez1@alu.uclm.es)

Asignatura:
	Multimedia, Hipermedia y Realidad Virtual
	Curso 2009-2010
	Escuela Superior de Inform�tica de Ciudad Real
	Universidad de Castilla - La Mancha
