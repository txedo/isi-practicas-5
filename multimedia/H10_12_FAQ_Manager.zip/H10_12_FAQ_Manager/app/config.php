<?php
	$server = "localhost";
	$database = "mhrv";
	$login = "mhrv";
	$password = "mhrvpass";
?>