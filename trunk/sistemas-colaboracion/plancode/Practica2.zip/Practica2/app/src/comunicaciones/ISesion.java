package comunicaciones;

public interface ISesion {
	public final String SESION = "sesionPlancode";
	public final String TIPO_SESION = "socket";
}
