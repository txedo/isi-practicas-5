package comunicaciones.EventosCanales;

import java.util.EventListener;

public interface MensajeTrazoListener extends EventListener {
		
		public void MensajeTrazo(MensajeTrazoEvent evt);


}
