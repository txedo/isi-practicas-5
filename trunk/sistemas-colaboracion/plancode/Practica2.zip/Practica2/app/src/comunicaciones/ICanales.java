package comunicaciones;

public interface ICanales {
	public final String CANAL_CHAT = "canalChat";
	public final String CANAL_DIBUJO = "canalDibujo";
	public final String CANAL_GESTION_ROL = "canalGestionRol";
	public final String CANAL_GESTION_LISTA = "canalGestionListaUsuarios";
	public final String CANAL_MAPA = "canalMapa";
}
