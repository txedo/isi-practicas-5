package excepciones;

public class NoSlotsDisponiblesException extends Exception {

}
