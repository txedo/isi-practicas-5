package dominio;

import dominio.control.ControladorPrincipal;

public class Main {

	public static void main(String[] args) {
		ControladorPrincipal c;
		c = new ControladorPrincipal();
		c.mostrarVentanaLogin();
	}

}
