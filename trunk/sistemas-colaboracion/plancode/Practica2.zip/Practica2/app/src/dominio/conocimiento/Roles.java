package dominio.conocimiento;

public enum Roles {

	Policia,
	Bombero,
	Sanidad
}
