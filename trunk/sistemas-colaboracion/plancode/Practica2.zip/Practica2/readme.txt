PlanCode - Planificador Colaborativo para el Dise�o de Estrategias y Acciones de
Emergencia
--------------------------------------------
Autores:
	Juan Andrada Romero (juan.andrada@uclm.es)
	Jose Domingo Lopez Lopez (josed.lopez1@alu.uclm.es)

Asignatura:
	Sistemas para la Colaboraci�n
	Curso 2009-2010
	Escuela Superior de Inform�tica de Ciudad Real
	Universidad de Castilla - La Mancha
